import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import org.junit.jupiter.params.provider.ValueSource;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class EuclideanAlgorithmTest {
    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, 4, -1})
    public void gcd_with0As1st_shouldReturnAbsValueOf2nd(int m){
        //Arrange
        final int n = 0;
        final int expected = Math.abs(m);
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n, m);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }
    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, 4, -1})
    public void gcd_with0As2nd_shouldReturnAbsValueOf1st(int n){
        //Arrange
        final int m = 0;
        final int expected = Math.abs(n);
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n, m);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, 4})
    public void gcd_with1As1st_shouldReturn1(int m){
        //Arrange
        final int n = 1;
        final int expected = 1;
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n, m);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }

    @ParameterizedTest
    @ValueSource(ints = {1, 2, 3, 4})
    public void gcd_with1As2nd_shouldReturn1(int n){
        //Arrange
        final int m = 1;
        final int expected = 1;
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n, m);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }

    @ParameterizedTest
    @CsvSource({
            "3, 5",
            "8, 4",
            "6, 12",
            "6, 18",
    })
    public void gcd_withSwappedValues_shouldReturnSame(int n, int m){
        //Arrange
        final int expected = EuclideanAlgorithm.greatestCommonDivisor(n, m);
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(m, n);

        //Assert
        assertEquals(expected, actual, failureMessage);


    }

    @ParameterizedTest
    @ValueSource(ints = {-2, 3, 5, 12, 7})
    public void gcd_withSameValues_shouldReturnAbsValueOfParam(int n){
        //Arrange
        final int expected = Math.abs(n);
        final String failureMessage = "gcd(" + n + ", " + n + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n,n);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }

    @ParameterizedTest
    @CsvSource({
            "2, 4, 3",
            "3, 6, 4",
            "9, 3, 2",
    })
    public void gcd_withPreFactoredParameters_shouldReturnGCDMultiplicatedWithFactor(int n, int m, int r){
        //Arrange
        final int expected = EuclideanAlgorithm.greatestCommonDivisor(n, m) * Math.abs(r);
        final String failureMessage = "gcd(" + n + ", " + m + ")";

        //Act
        final int actual = EuclideanAlgorithm.greatestCommonDivisor(n*r, m*r);

        //Assert
        assertEquals(expected, actual, failureMessage);
    }
}
