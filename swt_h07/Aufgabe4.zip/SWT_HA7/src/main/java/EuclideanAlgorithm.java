public class EuclideanAlgorithm {
    //is recursive but needs to be iterative
    public static int greatestCommonDivisor(int n, int m){
        if(n == 0){return Math.abs(m);}
        if(m == 0){return Math.abs(n);}
        while(n != m){
            if(n > m){
                n = n - m;
            }else{
                m = m - n;
            }
        }
        return Math.abs(n);
    }
}
